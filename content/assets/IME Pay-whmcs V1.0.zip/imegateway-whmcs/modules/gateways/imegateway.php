<?php
/**
 * WHMCS Imepay Payment Gateway Module
 *
 * Payment Gateway modules allow you to integrate payment solutions with the
 * WHMCS platform.
 *
 *
 *
 * Within the module itself, all functions must be prefixed with the module
 * filename, followed by an underscore, and then the function name. For this
 * example file, the filename is "imegateway" and therefore all functions
 * begin "imegateway_".
 *
 * 
 * For more information, please refer to the online documentation.
 *
 * @see https://imepay.com.np
 *
 */

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}


function imegateway_MetaData()
{
    return array(
        'DisplayName' => 'IMEpay Payment Gateway',
        'APIVersion' => '1.1', // Use API Version 1.1
        'DisableLocalCredtCardInput' => true,
        'TokenisedStorage' => false,
    );
}


function imegateway_config()
{
    return array(
        // the friendly display name for a payment gateway should be
        // defined here for backwards compatibility
        'FriendlyName' => array(
            'Type' => 'System',
            'Value' => 'IMEpay Payment Gateway',
        ),
        // a text field type allows for single line text input
        'ApiUsername' => array(
            'FriendlyName' => 'Api Username',
            'Type' => 'text',
            'Size' => '25',
            'Default' => '',
            'Description' => 'Enter your Api Username here provided by IMEpay',
        ),
        'MerchantCode' => array(
            'FriendlyName' => 'Merchant Code',
            'Type' => 'password',
            'Size' => '25',
            'Default' => '',
            'Description' => 'Enter your Merchant Code here provided by IMEpay',
        ),
        // a password field type allows for masked text input
        'secretKey' => array(
            'FriendlyName' => 'User Password Key',
            'Type' => 'password',
            'Size' => '25',
            'Default' => '',
            'Description' => 'Enter password here provided by IMEpay',
        ),
        'module' => array(
            'FriendlyName' => 'Module Name',
            'Type' => 'text',
            'Size' => '25',
            'Default' => '',
            'Description' => 'Enter your module here provided by IMEpay',
        ),
        // the yesno field type displays a single checkbox option
        'testMode' => array(
            'FriendlyName' => 'Test Mode',
            'Type' => 'yesno',
            'Description' => 'Tick to enable test mode',
        ),
        // the dropdown field type renders a select menu of options
        
    );
}

/**
 * Payment link.
 *
 * Required by third party payment gateway modules only.
 *
 * Defines the HTML output displayed on an invoice. Typically consists of an
 * HTML form that will take the user to the payment gateway endpoint.
 *
 * @param array $params Payment Gateway Module Parameters
 *
 * @see https://developers.whmcs.com/payment-gateways/third-party-gateway/
 *
 * @return string
 */



function receive_token($merchantcode,$amt,$ref_id,$apiuser,$password,$module,$testMode){
            
    $data = array("MerchantCode" => $merchantcode, "RefId" => (string)$ref_id, "Amount" => $amt);
    $header_array = [];
    $header_array[] = "Authorization: Basic ".base64_encode($apiuser.":".$password);
    $header_array[] = "Module: ".base64_encode($module);
    $header_array[] = "Content-Type: application/json";

    // Initializing a cURL session

    if($testMode == 'on' || $testMode === true){
        $urltoken = 'https://stg.imepay.com.np:7979/api/Web/GetToken';   //enter test mode url here
    }else{
        $urltoken = 'https://payment.imepay.com.np:7979/api/Web/GetToken';        //enter live mode url here
    }

    $cur = curl_init();
    
    if (!$cur) {
        die("Couldn't initialize a cURL handle");
    }
    curl_setopt($cur, CURLOPT_URL, $urltoken);
    curl_setopt($cur, CURLOPT_HTTPHEADER, $header_array);
    curl_setopt($cur, CURLOPT_POST, 1);
    curl_setopt($cur, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($cur, CURLOPT_RETURNTRANSFER, 1);

    
    $result = curl_exec($cur);
    
    if (curl_errno($cur)) {
        print "Error: " . curl_error($cur);
    }
    
    curl_close($cur);
    
    
    
    return $result;
}
 
function imegateway_current_page(){
    $filename = basename($_SERVER['SCRIPT_FILENAME']);
    return str_replace(".PHP", "", strtoupper($filename));
}

function imegateway_processing_code(){
    return <<<EOT
        <h3>Processing <i class='fa fa-spin fa-circle-notch'></i></h3>
EOT;
} 

function imegateway_noinvoicepage_code(){
    return <<<EOT
    <div class='row'>
    <div class='col-sm-6 col-sm-offset-3'>
    <h3>You are being redirected to the invoice page. </h3>
    <hr />
    <h4>You can choose to pay with the balance on your <strong>IMEpay Digital Wallet</strong> 
    <br />
    
    </div>
    </div>
EOT;
}


function imegateway_invoicepage_code($params){

    $ApiUsername = $params['ApiUsername'];
    $MerchantCode = $params['MerchantCode'];
    $secretKey = $params['secretKey'];
    $module = $params['module'];
    $testMode = $params['testMode'];
    
    // Invoice Parameters
    $invoiceId = $params['invoiceid'];
    $description = $params["description"];
    $amount = $params['amount'];
    $currencyCode = $params['currency'];

    // Client Parameters
    $firstname = $params['clientdetails']['firstname'];
    $lastname = $params['clientdetails']['lastname'];
    $email = $params['clientdetails']['email'];
    $address1 = $params['clientdetails']['address1'];
    $address2 = $params['clientdetails']['address2'];
    $city = $params['clientdetails']['city'];
    $state = $params['clientdetails']['state'];
    $postcode = $params['clientdetails']['postcode'];
    $country = $params['clientdetails']['country'];
    $phone = $params['clientdetails']['phonenumber'];

    // System Parameters
    $companyName = $params['companyname'];
    $systemUrl = $params['systemurl'];
    $returnUrl = $params['returnurl'];
    $langPayNow = $params['langpaynow'];
    $moduleDisplayName = $params['name'];
    $moduleName = $params['paymentmethod'];
    $whmcsVersion = $params['whmcsVersion'];



    $token_responses = receive_token($MerchantCode,$amount,$invoiceId,$ApiUsername,$secretKey,$module,$testMode);
    $token_response = json_decode($token_responses);

    $resptokenId=$token_response->TokenId;
    $responseCode=$token_response->ResponseCode;
    
    
    if($testMode == 'on' || $testMode === true){
        $url = 'https://stg.imepay.com.np:7979/WebCheckout/Checkout';   //enter test mode url here
    }else{
        $url = 'https://payment.imepay.com.np:7979/WebCheckout/Checkout';        //enter live mode url here
    }
    
    
    $responseurl=$systemUrl."/modules/gateways/callback/imegateway.php";
    $CancelUrl=$systemUrl."/modules/gateways/callback/imegateway.php";
    
    $postfields = array();
    $postfields['TokenId'] = $resptokenId;
    $postfields['MerchantCode'] = $MerchantCode;
    $postfields['RefId'] = $invoiceId;
    $postfields['TranAmount'] = $amount;
    $postfields['RespUrl'] =htmlentities ($responseurl);
    $postfields['CancelUrl'] =htmlentities ($CancelUrl);
    

    $htmlOutput = '<form method="post" action="' . $url . '">';
    foreach ($postfields as $k => $v) {
        $htmlOutput .= '<input type="hidden" name="' . $k . '" value="' . urlencode($v) . '" />';
    }

    $htmlOutput .= '<input class="btn btn-primary btn-large" type="submit" value="' . $langPayNow . '" />';
    $htmlOutput .= '</form>';

    $processingCode = imegateway_processing_code();

    $buttonCSS = "";
        
    $imageurl=$systemUrl.'/modules/gateways/imegateway/imelogo.png';
    
    return <<<EOT

    
    <div class='row' id='imegateway-button-wrapper'>
        <div class='col-sm-12' style='padding:2em;'>
            <div class='row' id='imegateway-processing' style='display:none'>
                <div class='col-sm-12'>
                    {$processingCode}
                </div>
            </div>
            <div class='row' id='imegateway-button-content'>
                <div class='col-sm-5'>
                    <div class='thumbnail' style='border:0px;box-shadow:none; margin-top:2em;'>
                        <img src='{$imageurl}' />
                    </div>
                </div>
                <div class='col-sm-7 text-left' style='border-left:1px solid #f9f9f9'>
                    <small>You can pay with IMEpay Wallet</small>
                    <br />
                    <br />
                    {$htmlOutput}
                </div>
            </div>
        </div>
    </div>
    
EOT;
}



function imegateway_link($params)
{
    $currentPage = imegateway_current_page();
    if($currentPage !== "VIEWINVOICE"){
        // Wait for the page to be redirected to the invoice page.
        return imegateway_noinvoicepage_code();
    }
    return  imegateway_invoicepage_code($params);
}

/**
 * Refund transaction.
 *
 * Called when a refund is requested for a previously successful transaction.
 *
 * @param array $params Payment Gateway Module Parameters
 *
 * @see https://developers.whmcs.com/payment-gateways/refunds/
 *
 * @return array Transaction response status
 */
function imegateway_refund($params)
{
    return false;
    // Gateway Configuration Parameters
    $accountId = $params['accountID'];
    $secretKey = $params['secretKey'];
    $testMode = $params['testMode'];
    $dropdownField = $params['dropdownField'];
    $radioField = $params['radioField'];
    $textareaField = $params['textareaField'];

    // Transaction Parameters
    $transactionIdToRefund = $params['transid'];
    $refundAmount = $params['amount'];
    $currencyCode = $params['currency'];

    // Client Parameters
    $firstname = $params['clientdetails']['firstname'];
    $lastname = $params['clientdetails']['lastname'];
    $email = $params['clientdetails']['email'];
    $address1 = $params['clientdetails']['address1'];
    $address2 = $params['clientdetails']['address2'];
    $city = $params['clientdetails']['city'];
    $state = $params['clientdetails']['state'];
    $postcode = $params['clientdetails']['postcode'];
    $country = $params['clientdetails']['country'];
    $phone = $params['clientdetails']['phonenumber'];

    // System Parameters
    $companyName = $params['companyname'];
    $systemUrl = $params['systemurl'];
    $langPayNow = $params['langpaynow'];
    $moduleDisplayName = $params['name'];
    $moduleName = $params['paymentmethod'];
    $whmcsVersion = $params['whmcsVersion'];

    // perform API call to initiate refund and interpret result

    return array(
        // 'success' if successful, otherwise 'declined', 'error' for failure
        'status' => 'success',
        // Data to be recorded in the gateway log - can be a string or array
        'rawdata' => $responseData,
        // Unique Transaction ID for the refund transaction
        'transid' => $refundTransactionId,
        // Optional fee amount for the fee value refunded
        'fees' => $feeAmount,
    );
}

/**
 * Cancel subscription.
 *
 * If the payment gateway creates subscriptions and stores the subscription
 * ID in tblhosting.subscriptionid, this function is called upon cancellation
 * or request by an admin user.
 *
 * @param array $params Payment Gateway Module Parameters
 *
 * @see https://developers.whmcs.com/payment-gateways/subscription-management/
 *
 * @return array Transaction response status
 */
