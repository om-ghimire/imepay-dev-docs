=== WooCommerce Imepay ===
Contributors: Ankit Shah, Protozoa Host, Imepay
Tags: woocommerce, Imepay
Requires at least: 4.0
Tested up to: 4.3
Stable tag: 1.2.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Adds Imepay as payment gateway in WooCommerce plugin.

== Description ==

= Add Imepay gateway to WooCommerce =

This plugin adds Imepay gateway to WooCommerce.

Please notice that [WooCommerce](http://wordpress.org/plugins/woocommerce/) must be installed and active.

= Introduction =

Add Imepay as a payment method in your WooCommerce store.

[Imepay](https://Imepay.com.np/) is a Nepali Digital Payment Portal developed by Ime Group . This means that if your store doesn't accept payment in NPR, you really do not need this plugin!!!


= Requirements =

* WordPress 4.0 or later.
* WooCommerce 2.3 or later.

= Installation =

Check out our installation guide and configuration of WooCommerce Imepay tab check documentation provided by IME Pay.

== Installation ==

* Upload plugin files to your plugins folder, or install using WordPress built-in Add New Plugin installer;
* Activate the plugin;
* This ready! You can now navigate to WooCommerce -> Settings -> Payment Gateways, choose Imepay and fill in your credentials.

== Frequently Asked Questions ==

= What is the plugin license? =

* This plugin is released under a GPL license.

= What is needed to use this plugin? =

* WordPress 4.0 or later.
* WooCommerce 2.3 or later.
* Merchant/Service Code from Imepay.

= Imepay receives payments from which countries? =

At the moment the Imepay receives payments only from Nepal.

Configure the plugin to receive payments only users who select Nepal in payment information during checkout.
