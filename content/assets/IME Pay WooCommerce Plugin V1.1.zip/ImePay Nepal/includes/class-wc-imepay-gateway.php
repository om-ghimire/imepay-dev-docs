<?php
/**
 * imepay Payment Gateway.
 *
 * Provides a imepay Payment Gateway.
 *
 * @class    WC_Gateway_imepay
 * @extends  WC_Payment_Gateway
 * @category Class
 * @author   Ankit Shah
 * @since    1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WC_Gateway_imepay Class.
 */
class WC_Gateway_imepay extends WC_Payment_Gateway {

	/** @var bool Whether or not logging is enabled */
	public static $log_enabled = false;

	/** @var WC_Logger Logger instance */
	public static $log = false;

	/**
	 * Constructor for the gateway.
	 */
	public function __construct() {
		$this->id                 = 'imepay';
		$this->icon               = apply_filters( 'woocommerce_imepay_icon', plugins_url( 'assets/images/imepay.png', plugin_dir_path( __FILE__ ) ) );
		$this->has_fields         = false;
		$this->order_button_text  = __( 'Pay with IME Pay', 'imepay-nepal' );
		$this->method_title       = __( 'IME Pay', 'imepay-nepal' );
		$this->method_description = sprintf( __( 'The IMEpay system sends customers to IMEpay to enter their payment information.', 'imepay-nepal' ), '<a href="' . admin_url( 'admin.php?page=wc-status' ) . '">', '</a>' );

		// Load the settings.
		$this->init_form_fields();
		$this->init_settings();

		// Define user set variables.
		$this->title        = $this->get_option( 'title' );
		$this->description  = $this->get_option( 'description' );
		$this->testmode     = 'yes' === $this->get_option( 'testmode', 'no' );
		$this->debug        = 'yes' === $this->get_option( 'debug', 'no' );
		$this->ime_username = $this->get_option( 'ime_username' );
		$this->merchant_code = $this->get_option( 'merchant_code' );
		$this->password_code = $this->get_option( 'password_code' );
		$this->module_name = $this->get_option( 'module_name' );

		self::$log_enabled  = $this->debug;

		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );

		if ( ! $this->is_valid_for_use() ) {
			$this->enabled = 'no';
		} elseif ( $this->ime_username ) {
			include_once( dirname( __FILE__ ) . '/includes/class-wc-gateway-imepay-ipn-handler.php' );
			new WC_Gateway_imepay_IPN_Handler( $this, $this->testmode, $this->ime_username );
		}
	}

	/**
	 * Logging method.
	 * @param string $message
	 */
	public static function log( $message ) {
		if ( self::$log_enabled ) {
			if ( empty( self::$log ) ) {
				if ( version_compare( WC_VERSION, '2.7', '>=' ) ) {
					self::$log = wc_get_logger();
				} else {
					self::$log = new WC_Logger();
				}
			}
			self::$log->add( 'IME Pay', $message );
		}
	}

	/**
	 * Check if this gateway is enabled and available in the user's country.
	 * @return bool
	 */
	public function is_valid_for_use() {
		return in_array( get_woocommerce_currency(), apply_filters( 'woocommerce_imepay_supported_currencies', array( 'NPR' ) ) );
	}

	/**
	 * Admin Panel Options.
	 * - Options for bits like 'title' and availability on a country-by-country basis.
	 *
	 * @since 1.0.0
	 */
	public function admin_options() {
		if ( $this->is_valid_for_use() ) {
			parent::admin_options();
		} else {
			?>
			<div class="inline error"><p><strong><?php _e( 'Gateway Disabled', 'imepay-nepal' ); ?></strong>: <?php _e( 'IMEpay does not support your store currency.', 'imepay-nepal' ); ?></p></div>
			<?php
		}
	}

	/**
	 * Initialise Gateway Settings Form Fields.
	 */
	public function init_form_fields() {
		$this->form_fields = include( 'includes/settings-imepay.php' );
	}

	
	/**
	 * Process the payment and return the result.
	 *
	 * @param  int $order_id
	 * @return array
	 */
	public function process_payment( $order_id ) {
		include_once( dirname( __FILE__ ) . '/includes/class-wc-gateway-imepay-request.php' );

		$order         = wc_get_order( $order_id );
		$imepay_request = new WC_Gateway_imepay_Request( $this );

		return array(
			'result'   => 'success',
			'redirect' => $imepay_request->get_request_url( $order, $this->testmode ),
		);
	}
}
