<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

include_once( dirname( __FILE__ ) . '/class-wc-gateway-imepay-response.php' );

/**
 * Handles IPN Responses from imepay.
 */

class WC_Gateway_imepay_IPN_Handler extends WC_Gateway_imepay_Response {

	/** @var string Service code for IPN support */
	protected $ime_username;
	protected $merchant_code;
	protected $password_code;
	protected $module_name;
	
	/**
	 * Constructor.
	 * @param WC_Gateway_imepay $gateway
	 * @param bool             $sandbox
	 * @param string           $ime_username
	 */
	public function __construct( $gateway, $sandbox = false, $ime_username = '' ) {
		add_action( 'woocommerce_api_wc_gateway_imepay', array( $this, 'check_response' ) );
		add_action( 'valid-imepay-standard-ipn-request', array( $this, 'valid_response' ) );

		$this->success = isset($_POST["ResponseCode"])?$_POST["ResponseCode"]:null;
		$this->invoiceId = isset($_POST["RefId"])?$_POST["RefId"]:null;
		$this->transactionId = isset($_POST["TransactionId"])?$_POST["TransactionId"]:null;
		$this->paymentAmount = isset($_POST["TranAmount"])?$_POST["TranAmount"]:null;
		$this->Msisdn = isset($_POST["Msisdn"])?$_POST["Msisdn"]:null;
        $this->tokenid=isset($_GET['tokenids'])?$_GET['tokenids']:null;
		$this->ime_username = $ime_username;
		$this->sandbox      = $sandbox;
		$this->gateway      = $gateway;
	}

	/**
	 * Check for imepay IPN Response.
	 */
	public function check_response() {
		@ob_clean();
		
		if ( $this->success==0 && $this->validate_ipn() ) {
			$requested = wp_unslash( $_REQUEST );

			do_action( 'valid-imepay-standard-ipn-request', $requested );
			exit;
		}else{
		    $requested = wp_unslash( $_REQUEST );

			do_action( 'valid-imepay-standard-ipn-request', $requested );
			exit;
		}

		wp_die( 'IME Pay IPN Request Failure', 'imepay IPN', array( 'response' => 500 ) );
	}

	/**
	 * There was a valid response.
	 * @param array $requested Request data after wp_unslash
	 */
	public function valid_response( $requested ) {
		if ( ! empty( $requested['key'] ) && $order = $this->get_imepay_order( $this->invoiceId, $requested['key'] ) ) {

			// Lowercase returned variables.
			$requested['payment_status'] = strtolower( $requested['payment_status'] );

			// Validate transaction status.
			if ( isset($this->transactionId) && 0 == $this->success) {
				$requested['payment_status'] = 'completed';
				$requested['pending_reason'] = __( 'IME Pay IPN response failed.', 'imepay-nepal' );
			} else {
				$requested['payment_status'] = 'failed';
			}

			WC_Gateway_imepay::log( 'Found order #' . $order->id );
			WC_Gateway_imepay::log( 'Payment status: ' . $requested['payment_status'] );

			if ( method_exists( $this, 'payment_status_' . $requested['payment_status'] ) ) {
				call_user_func( array( $this, 'payment_status_' . $requested['payment_status'] ), $order, $requested );
				wp_redirect( esc_url( add_query_arg( 'utm_nooverride', '1', $this->gateway->get_return_url( $order ) ) ) );
			}
		}
	}

	/**
	 * Check imepay IPN validity.
	 */
	public function validate_ipn() {
	    
	    
	    $data = ["MerchantCode" =>  $this->gateway->get_option( 'merchant_code' ), "RefId" => $this->invoiceId,"TokenId" =>$this->tokenid];
		
		$header_array = [];
        $header_array[] = "Authorization: Basic ".base64_encode($this->gateway->get_option( 'ime_username' ).":".$this->gateway->get_option( 'password_code' ));
        $header_array[] = "Module: ".base64_encode($this->gateway->get_option( 'module_name' ));
		$header_array[] = "Content-Type: application/json";
		
		if ( $this->gateway->get_option( 'testmode' )=="yes" ) {
			$this->recheck = 'https://stg.imepay.com.np:7979/api/Web/Recheck';
		} else {
			$this->recheck = 'https://payment.imepay.com.np:7979/api/Web/Recheck';
		}
		
		$curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $this->recheck);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $header_array);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

        $result = curl_exec($curl);
        curl_close($curl);

		$responsecheck = json_decode($result);

    	$respid=$responsecheck->ResponseCode;

	    
	    
		$requested = wp_unslash( $_REQUEST );
		if($requested==0){
			return true;
		}else{
			return false;
		}

	}

	/**
	 * Check payment amount from IPN matches the order.
	 * @param WC_Order $order
	 * @param int      $amount
	 */
	protected function validate_amount( $order, $amount ) {
		if ( number_format( $order->get_total(), 2, '.', '' ) != number_format( $amount, 2, '.', '' ) ) {
			WC_Gateway_imepay::log( 'Payment error: Amounts do not match (gross ' . $amount . ')' );

			// Put this order on-hold for manual checking.
			$order->update_status( 'on-hold', sprintf( __( 'Validation error: IME Pay amounts do not match (gross %s).', 'imepay-nepal' ), $amount ) );
			exit;
		}
	}

	/**
	 * Handle a completed payment.
	 * @param WC_Order $order
	 * @param array    $requested
	 */
	protected function payment_status_completed( $order, $requested ) {
		if ( $order->has_status( 'completed' ) ) {
			WC_Gateway_imepay::log( 'Aborting, Order #' . $order->id . ' is already complete.' );
			exit;
		}

		$this->validate_amount( $order, $this->paymentAmount);

		if ( 'completed' === $requested['payment_status'] ) {
			$this->payment_complete( $order, ( ! empty( $this->transactionId ) ? wc_clean( $this->transactionId) : '' ), __( 'IPN payment completed', 'imepay-nepal' ) );
		} else {
			$this->payment_on_hold( $order, sprintf( __( 'Payment pending: %s', 'imepay-nepal' ), $requested['pending_reason'] ) );
		}
	}

	/**
	 * Handle a failed payment.
	 * @param WC_Order $order
	 * @param array    $requested
	 */
	protected function payment_status_failed( $order, $requested ) {
		$order->update_status( 'failed', sprintf( __( 'Payment %s via IPN.', 'imepay-nepal' ), wc_clean( $requested['payment_status'] ) ) );
	}
}
