<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Settings for imepay Gateway.
 */
return array(
	'enabled' => array(
		'title'   => __( 'Enable/Disable', 'imepay-nepal' ),
		'type'    => 'checkbox',
		'label'   => __( 'Enable IME pay Payment', 'imepay-nepal' ),
		'default' => 'yes',
	),
	'title' => array(
		'title'       => __( 'Title', 'imepay-nepal' ),
		'type'        => 'text',
		'desc_tip'    => true,
		'description' => __( 'This controls the title which the user sees during checkout.', 'imepay-nepal' ),
		'default'     => __( 'IME Pay', 'imepay-nepal' ),
	),
	'description' => array(
		'title'       => __( 'Description', 'imepay-nepal' ),
		'type'        => 'text',
		'desc_tip'    => true,
		'description' => __( 'This controls the description which the user sees during checkout.', 'imepay-nepal' ),
		'default'     => __( 'Pay via IME Pay; you can pay with IME Pay account securely.', 'imepay-nepal' ),
	),
	'ime_username' => array(
		'title'       => __( 'IME Pay Username', 'imepay-nepal' ),
		'type'        => 'text',
		'desc_tip'    => true,
		'description' => __( 'Please enter your IME Pay Service Code; this is needed in order to take payment.', 'imepay-nepal' ),
		'default'     => '',
		'placeholder' => 'Eg: Woo',
	),
	'password_code' => array(
		'title'       => __( 'Password code', 'imepay-nepal' ),
		'type'        => 'password',
		'desc_tip'    => true,
		'description' => __( 'Please enter your IME Pay Password Code; this is needed in order to take payment.', 'imepay-nepal' ),
		'default'     => '',
		'placeholder' => 'Eg: Woo',
	),
	'merchant_code' => array(
		'title'       => __( 'Merchant code', 'imepay-nepal' ),
		'type'        => 'password',
		'desc_tip'    => true,
		'description' => __( 'Please enter your IME Pay Merchant Code; this is needed in order to take payment.', 'imepay-nepal' ),
		'default'     => '',
		'placeholder' => 'Eg: Woo',
	),
	
	'module_name' => array(
		'title'       => __( 'Module', 'imepay-nepal' ),
		'type'        => 'text',
		'desc_tip'    => true,
		'description' => __( 'Please enter your IME Pay Module Name; this is needed in order to take payment.', 'imepay-nepal' ),
		'default'     => '',
		'placeholder' => 'Eg: Woo',
	),
	'invoice_prefix' => array(
		'title'       => __( 'Invoice prefix', 'imepay-nepal' ),
		'type'        => 'text',
		'desc_tip'    => true,
		'description' => __( 'Please enter a prefix for your invoice numbers. If you use your IME Pay account for multiple stores ensure this prefix is unique as IME Pay will not allow orders with the same invoice number.', 'imepay-nepal' ),
		'default'     => 'WC-',
	),
	'testmode' => array(
		'title'       => __( 'Sandbox mode', 'imepay-nepal' ),
		'type'        => 'checkbox',
		'label'       => __( 'Enable Sandbox Mode', 'imepay-nepal' ),
		'default'     => 'no',
		'description' => sprintf( __( 'Enable IME Pay sandbox to test payments. Sign up for a developer account %1$shere%2$s.', 'imepay-nepal' ), '<a href="https://imepay.com.np/" target="_blank">', '</a>' ),
	),
	'debug' => array(
		'title'       => __( 'Debug log', 'imepay-nepal' ),
		'type'        => 'checkbox',
		'label'       => __( 'Enable logging', 'imepay-nepal' ),
		'default'     => 'no',
		'description' => sprintf( __( 'Log IME Pay events, such as IPN requests, inside <code>%s</code>', 'imepay-nepal' ), wc_get_log_file_path( 'imepay' ) ),
	),
);
