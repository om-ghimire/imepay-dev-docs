<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Generates requests to send to imepay.
 */
class WC_Gateway_imepay_Request {

	/**
	 * Pointer to gateway making the request.
	 * @var WC_Gateway_imepay
	 */
	protected $gateway;

	/**
	 * Endpoint for requests from imepay.
	 * @var string
	 */
	protected $notify_url;

	/**
	 * Constructor.
	 * @param WC_Gateway_imepay $gateway
	 */
	public function __construct( $gateway ) {
		$this->gateway    = $gateway;
		$this->notify_url = WC()->api_request_url( 'WC_Gateway_imepay' );
	}

	/**
	 * Get the imepay request URL for an order.
	 * @param  WC_Order $order
	 * @param  bool     $sandbox
	 * @return string
	 */
	public function get_request_url( $order, $sandbox = false ) {
	    
		$imepay_args = http_build_query( array_filter( $this->get_imepay_args( $order ) ), '', '&' );

		WC_Gateway_imepay::log( 'IME Pay Request Args for order ' . $order->get_order_number() . ': ' . print_r( $imepay_args, true ) );
		
		if ( $sandbox ) {
			$this->post_url = 'https://stg.imepay.com.np:7979/WebCheckout/Checkout';
		} else {
			$this->post_url = 'https://payment.imepay.com.np:7979/WebCheckout/Checkout';
		}
		
		

		return $this->post_url.'?' . $imepay_args;
		
	}

	/**
	 * Limit length of an arg.
	 *
	 * @param  string  $string
	 * @param  integer $limit
	 * @return string
	 */
	protected function limit_length( $string, $limit = 127 ) {
		if ( strlen( $string ) > $limit ) {
			$string = substr( $string, 0, $limit - 3 ) . '...';
		}
		return $string;
	}

	/**
	 * Get imepay Args for passing to imepay.
	 * @param  WC_Order $order
	 * @return array
	 */
	protected function get_imepay_args( $order ) {
		WC_Gateway_imepay::log( 'Generating payment form for order ' . $order->get_order_number() . '. Notify URL: ' . $this->notify_url );

		$data = ["MerchantCode" =>  $this->gateway->get_option( 'merchant_code' ), "Amount" => wc_format_decimal( $order->get_total(), 2 ), "RefId" => $this->limit_length( $this->gateway->get_option( 'invoice_prefix' ) . $order->get_order_number(), 127 )];
		
		$header_array = [];
        $header_array[] = "Authorization: Basic ".base64_encode($this->gateway->get_option( 'ime_username' ).":".$this->gateway->get_option( 'password_code' ));
        $header_array[] = "Module: ".base64_encode($this->gateway->get_option( 'module_name' ));
		$header_array[] = "Content-Type: application/json";
		
		if ( $this->gateway->get_option( 'testmode' )=="yes" ) {
			$this->token_url = 'https://stg.imepay.com.np:7979/api/Web/GetToken';
		} else {
			$this->token_url = 'https://payment.imepay.com.np:7979/api/Web/GetToken';
		}
		
		$curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $this->token_url);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $header_array);
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 5);
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

        $result = curl_exec($curl);
        curl_close($curl);

		$token_response = json_decode($result);

    	$resptokenId=$token_response->TokenId;
    	$responseCode=$token_response->ResponseCode;
        
        $dataforsend=array(
			'TokenId'   => $resptokenId,
			'MerchantCode' => $this->gateway->get_option( 'merchant_code' ),
			'RefId'   => $this->limit_length( $this->gateway->get_option( 'invoice_prefix' ) . $order->get_order_number(), 127 ),
			'TranAmount'   => wc_format_decimal( $order->get_total(), 2 ),
			'Method'=>"POST",
			'RespUrl'    => esc_url_raw( add_query_arg( array( 'payment_status' => 'success', 'key' => $order->order_key,'tokenids'=> $resptokenId), $this->limit_length( $this->notify_url, 255 ) ) ),
			'CancelUrl'    => esc_url_raw( add_query_arg( array( 'payment_status' => 'failure', 'key' => $order->order_key,'tokenids'=> $resptokenId ), $this->limit_length( $this->notify_url, 255 ) ) ),
		);
		
		$getdatabuild=base64_encode($dataforsend['TokenId']."|".$dataforsend['MerchantCode']."|".$dataforsend['RefId']."|".$dataforsend['TranAmount']."|".$dataforsend['Method']."|".$dataforsend['RespUrl']."|".$dataforsend['CancelUrl']);
        
		return apply_filters( 'woocommerce_imepay_args', array(
			'data'   => $getdatabuild
		), $order );
	}

	/**
	 * Get the service charge to send to imepay.
	 * @param  WC_Order $order
	 * @return float
	 */
	
}
